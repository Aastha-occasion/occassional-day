<!--
This template is mainly for bug reports, but should also be used for feature requests if possible.
Note that leaving sections blank will make it difficult to find a solution and the issue might be closed.
-->

**Details about your environment:**
* Brackets Version: 
* Brackets Beautify Version: 

<!-- When reporting formatting issues add before, expected, and actual code. -->
<!-- For other problems, please describe how to reproduce and add logs from the Dev tools. -->
